// Cloudflare Pages Function: live observations from USGS, with a short edge cache.
const BASE = 'https://api.waterdata.usgs.gov/ogcapi/v1/collections/latest-continuous/items';
const SITE = 'USGS-14211720';
const CODES = ['00010', '00055', '00060', '00065'];

function selectObservations(data) {
  const features = Array.isArray(data.features) ? data.features : [];
  const result = {};
  for (const f of features) {
    const p = f.properties || f;
    const code = String(p.parameter_code || '');
    if (!CODES.includes(code)) continue;
    if (p.monitoring_location_id && p.monitoring_location_id !== SITE) continue;
    const value = Number(p.value);
    const time = p.time;
    if (!Number.isFinite(value) || !time || Number.isNaN(Date.parse(time))) continue;
    const observation = {value, time, unit: p.unit_of_measure || '', provisional: p.approval_status === 'Provisional'};
    if (!result[code] || Date.parse(time) > Date.parse(result[code].time)) result[code] = observation;
  }
  return result;
}

export async function onRequestGet({request}) {
  const endpoint = new URL(BASE);
  endpoint.searchParams.set('monitoring_location_id', SITE);
  endpoint.searchParams.set('f', 'json');
  endpoint.searchParams.set('limit', '100');
  const headers = {'content-type': 'application/json; charset=utf-8', 'cache-control': 'public, max-age=0, s-maxage=600'};
  try {
    const upstream = await fetch(endpoint.toString(), {headers: {accept: 'application/geo+json'}, cf: {cacheTtl: 600, cacheEverything: true}, signal: AbortSignal.timeout(12000)});
    if (!upstream.ok) throw new Error(`USGS returned HTTP ${upstream.status}`);
    const json = await upstream.json();
    const observations = selectObservations(json);
    if (!Object.keys(observations).length) throw new Error('No matching USGS observations found');
    return new Response(JSON.stringify({ok: true, site: SITE, fetchedAt: new Date().toISOString(), observations}), {headers});
  } catch (error) {
    return new Response(JSON.stringify({ok: false, error: 'River observations temporarily unavailable', detail: String(error.message || error)}), {status: 503, headers: {...headers, 'cache-control': 'no-store'}});
  }
}
