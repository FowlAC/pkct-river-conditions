# PKCT River Conditions Dashboard

A small, zero-dependency dashboard for the Portland Kayak & Canoe Team. Designed for **Cloudflare Pages** with **Pages Functions** and GitHub deployment. No database, API keys, paid hosting plan, build framework, or Replit required.

## What is live vs linked?

- **Live via USGS**: river temperature, current velocity, stage and discharge from station `USGS-14211720`.
- **Linked official resources** (not automatically extracted): City of Portland Check the Rec E. coli results; Big Pipe overflow advisory; Sellwood Weather Cam. These sources must not be presented as up-to-the-minute sensor feeds until their embed/API availability is established.
- USGS sensor location differs from PKCT's Oaks Park launch. Velocity is associated with Broadway Bridge; stage with Morrison Bridge.
- Data older than six hours is hidden, with a stale-data message. USGS data are provisional.

## Deploy through GitHub + Cloudflare Pages

1. Add the files in this package to the *root* of your GitHub repo `pkct-river-conditions`, preserving the `public/` and `functions/api/` folders. See GitHub upload notes below.
2. Sign in at https://dash.cloudflare.com/ and open **Workers & Pages**.
3. Select **Create application** → **Pages** → **Import an existing Git repository** (labels can vary).
4. Authorize GitHub if requested, choose `pkct-river-conditions`, and choose production branch **main**.
5. Configuration: **Framework preset** `None`; **Build command** `exit 0`; **Build output directory** `public`; **Root directory** repository root (leave blank if it means root).
6. Choose **Save and Deploy**. Cloudflare builds the site and Pages Function together.
7. Open the resulting `https://<project>.pages.dev/` URL; then open `https://<project>.pages.dev/api/conditions` to inspect the raw JSON response. A 503 means the USGS connection or response parser needs checking.
8. Once working, create a **Button Block** in Squarespace labeled `Check River Conditions` pointing to the `.pages.dev` URL.

### Uploading existing files to an already initialized GitHub repository

If you use GitHub's web UI, select **Add file → Upload files**, upload files while retaining directory structure. Some browsers don't preserve folders in every upload scenario; the most reliable path is to clone your repository and copy the unzipped project files into it, then commit and push. Do **not** upload the ZIP file alone; Cloudflare cannot run a ZIP as the repository source.

The `functions` directory must be at the **repository root**, not inside `public`.

## Free tier and accessibility

The frontend makes one request to `/api/conditions` on each page load or manual refresh. The Function fetches public USGS data and requests a 10-minute edge cache. Actual cache reuse can vary by Cloudflare placement and traffic. This is intended for low-volume club use.

## Local preview

The static interface can be viewed with `python3 -m http.server 8000 --directory public`, but live `/api/conditions` requires a Cloudflare Pages Functions runtime. On local static preview the UI will correctly show **Live data unavailable**.

## Debugging

- 404 on homepage: ensure build output directory is `public` and `public/index.html` exists.
- 404 on `/api/conditions`: ensure `functions/api/conditions.js` is at repo root; deploy through Git integration rather than dashboard Direct Upload.
- API 503: upstream USGS API could be unavailable, have changed field names, or be rejecting the request. Inspect Cloudflare Pages Functions logs and the `detail` field in JSON. Do not treat missing data as safe conditions.
- All readings unavailable: check `/api/conditions` response and the measurement timestamps.

## Sources

- USGS station: https://waterdata.usgs.gov/monitoring-location/USGS-14211720/
- USGS latest measurements API: https://api.waterdata.usgs.gov/ogcapi/v1/collections/latest-continuous
- Water quality: https://www.portland.gov/bes/check-rec
- Big Pipe: https://www.portland.gov/bes/big-pipe-tracker
- Camera: https://www.richmorgan.com/

## Next improvements

- Add a 24-hour chart using the USGS continuous observations API.
- Confirm availability, permissions and update cadence of official safety data and Sellwood camera before implementing any automatic status claim or inline camera image.
- Add custom domain `conditions.portlandkayakteam.org` after confirming domain DNS ownership.

## License

PKCT can modify and share the code. The data and content on external sites remain subject to those sources' own terms.
