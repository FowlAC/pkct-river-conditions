const SITE_TIMEZONE = 'America/Los_Angeles';
const MAX_AGE_HOURS = 6;
const measures = {
  temperature: {code: '00010', format: value => (value * 9 / 5 + 32).toFixed(1)},
  velocity: {code: '00055', format: value => (value * 0.681818).toFixed(2)},
  stage: {code: '00065', format: value => value.toFixed(2)},
  discharge: {code: '00060', format: value => Math.round(value).toLocaleString('en-US')}
};
const $ = id => document.getElementById(id);
function timeLabel(time) {
  return new Intl.DateTimeFormat('en-US',{timeZone:SITE_TIMEZONE,month:'short',day:'numeric',hour:'numeric',minute:'2-digit',timeZoneName:'short'}).format(new Date(time));
}
function renderMeasure(key, observation) {
  const valueEl = $(key), timeEl = $(`${key}-time`);
  if (!observation || Date.now() - Date.parse(observation.time) > MAX_AGE_HOURS * 3600000 || Date.parse(observation.time) > Date.now() + 300000) {
    valueEl.textContent = '—';
    timeEl.textContent = observation ? `Stale reading · ${timeLabel(observation.time)}` : 'No recent measurement';
    return false;
  }
  valueEl.textContent = measures[key].format(observation.value);
  timeEl.textContent = timeLabel(observation.time) + (observation.provisional ? ' · provisional' : '');
  return true;
}
async function loadData() {
  $('refresh').disabled = true;
  $('api-state').textContent = 'Updating…';
  $('api-state').className = 'status loading';
  try {
    const response = await fetch('/api/conditions', {cache:'no-store'});
    if (!response.ok) throw new Error('API unavailable');
    const data = await response.json();
    if (!data.ok) throw new Error('No observations');
    let fresh = 0;
    for (const [key, info] of Object.entries(measures)) {
      if (renderMeasure(key, data.observations[info.code])) fresh++;
    }
    $('api-state').textContent = fresh === 4 ? 'USGS data available' : fresh ? `${fresh} of 4 readings available` : 'Measurements unavailable';
    $('api-state').className = fresh === 4 ? 'status' : 'status warning';
  } catch (err) {
    for (const key of Object.keys(measures)) renderMeasure(key, null);
    $('api-state').textContent = 'Live data unavailable';
    $('api-state').className = 'status warning';
  } finally { $('refresh').disabled = false; }
}
$('refresh').addEventListener('click', loadData);
loadData();
